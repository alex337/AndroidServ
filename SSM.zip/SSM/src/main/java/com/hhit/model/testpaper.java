package com.hhit.model;

public class testpaper {

	private int nowid;
	private int preid;
	private String type;
	private String answer;
	public int getNowid() {
		return nowid;
	}
	public void setNowid(int nowid) {
		this.nowid = nowid;
	}
	public int getPreid() {
		return preid;
	}
	public void setPreid(int preid) {
		this.preid = preid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
