package com.hhit.service;


import com.hhit.model.choicequestion;

import java.util.List;

public interface ChoiceService {
    List<choicequestion> selectchoice();

}
