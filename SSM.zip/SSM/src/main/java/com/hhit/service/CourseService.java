package com.hhit.service;

import com.hhit.model.Course;

import java.util.List;

public interface CourseService {
    List<String> selectcourse(String teacherName);

}
