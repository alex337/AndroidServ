package com.hhit.dao;

import com.hhit.model.choicequestion;

import java.util.List;

public interface ChoiceDao {
   List<choicequestion> selectchoice();
}
